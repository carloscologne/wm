import { createFileRoute } from "@tanstack/react-router";
import { COUNTRIES, FACE_DESCRIPTION_PLACEHOLDER } from "@/lib/countries";
import { checkRateLimit, consumeRateLimit, getClientIp } from "@/lib/rate-limit";

export const Route = createFileRoute("/api/generate-wm-image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.OPENAI_API_KEY;
        if (!key) return new Response("Missing OPENAI_API_KEY", { status: 500 });

        const ip = getClientIp(request);
        const pre = checkRateLimit(ip);
        if (!pre.ok) {
          return Response.json(
            { error: "Tageslimit erreicht. Komm morgen wieder!" },
            { status: 429 },
          );
        }

        const { countryId, style, imageDataUrl, description } = (await request.json()) as {
          countryId: string;
          style: "retro" | "modern";
          imageDataUrl: string;
          description: string;
        };

        const country = COUNTRIES.find((c) => c.id === countryId);
        if (!country || (style !== "retro" && style !== "modern")) {
          return new Response("Invalid country/style", { status: 400 });
        }
        if (!imageDataUrl?.startsWith("data:image/")) {
          return new Response("Invalid image", { status: 400 });
        }

        const template = country.styles[style].prompt;
        const prompt = template.replace(
          FACE_DESCRIPTION_PLACEHOLDER,
          description?.trim() || "(no description available — preserve face exactly as in input image)",
        );

        // Convert input data URL → Blob for multipart upload to OpenAI /images/edits
        const inMatch = imageDataUrl.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
        if (!inMatch) return new Response("Invalid image data url", { status: 400 });
        const inMime = inMatch[1];
        const inBuf = Buffer.from(inMatch[2], "base64");
        const ext = inMime === "image/jpeg" ? "jpg" : inMime === "image/webp" ? "webp" : "png";
        const inputBlob = new Blob([inBuf], { type: inMime });

        const form = new FormData();
        form.append("model", "gpt-image-1");
        form.append("prompt", prompt);
        form.append("size", "1024x1024");
        form.append("quality", "low");
        form.append("image", inputBlob, `input.${ext}`);

        const upstream = await fetch("https://api.openai.com/v1/images/edits", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${key}`,
          },
          body: form,
        });

        if (!upstream.ok) {
          const text = await upstream.text();
          console.error("[generate-wm-image] upstream", upstream.status, text);
          if (upstream.status === 429) {
            return Response.json(
              { error: "AI Gateway Rate Limit. Bitte kurz warten." },
              { status: 429 },
            );
          }
          if (upstream.status === 402) {
            return Response.json(
              { error: "AI Gateway Guthaben aufgebraucht." },
              { status: 402 },
            );
          }
          return new Response(text || "Upstream error", { status: upstream.status });
        }

        const json = (await upstream.json()) as {
          data?: { b64_json?: string }[];
        };
        const b64 = json.data?.[0]?.b64_json;
        if (!b64) {
          console.error("[generate-wm-image] no image in response", JSON.stringify(json).slice(0, 500));
          return new Response("No image returned", { status: 502 });
        }

        consumeRateLimit(ip);
        return Response.json({ imageBase64: b64, mimeType: "image/png" });
      },
    },
  },
});