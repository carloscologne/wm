## Ziel
Eigenen OpenAI API Key hinterlegen und die Bildgenerierung von Lovable AI Gateway (`google/gemini-3-pro-image-preview`) auf OpenAI (`gpt-image-1`) umstellen.

## Schritte

1. **Secret anlegen**
   - `OPENAI_API_KEY` via Secrets-Tool hinzufügen (du gibst den Key in einem sicheren Formular ein).
   - Key bekommst du unter https://platform.openai.com/api-keys.

2. **Server Route umstellen** (`src/routes/api/generate-wm-image.ts`)
   - Statt `https://ai.gateway.lovable.dev/v1/images/generations` direkt `https://api.openai.com/v1/images/generations` aufrufen.
   - Authentifizierung: `Authorization: Bearer ${process.env.OPENAI_API_KEY}`.
   - Model: `gpt-image-1`, `size: "1024x1024"`, `quality: "low"`.
   - Hinweis: OpenAI `gpt-image-1` unterstützt im direkten API-Call **kein Streaming mit `partial_images`** wie der Gateway-Proxy. Antwort kommt als JSON mit `data[0].b64_json` — die Route gibt dann ein fertiges Bild zurück (kein progressives Blur-Preview mehr).

3. **Client anpassen** (`src/components/wm/Result.tsx` o.ä.)
   - SSE-Parser entfernen, stattdessen normalen `fetch().json()` Call, `b64_json` → `data:image/png;base64,...` setzen.
   - Loading-State (Spinner) statt progressivem Blur.

4. **Wasserzeichen** unten rechts bleibt unverändert (clientseitiges Canvas-Overlay).

## Hinweise
- Kosten laufen ab jetzt über dein OpenAI-Konto, nicht mehr über Lovable Credits.
- `LOVABLE_API_KEY` bleibt bestehen (falls andere Features ihn nutzen).
- Falls du das progressive Preview behalten willst, müsste man bei Lovable AI Gateway bleiben — sag Bescheid, dann mache ich es hybrid (OpenAI-Key optional).
