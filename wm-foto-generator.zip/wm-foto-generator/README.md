# WM Foto Generator

Verwandle dein Selfie in einen Fußball-Star — Deutschland oder Portugal, Retro oder Modern.

## Setup

### 1. Dependencies installieren
```bash
npm install
```

### 2. Environment Variables
```bash
cp .env.local.example .env.local
```

Dann in `.env.local` deinen OpenAI API Key eintragen:
```
OPENAI_API_KEY=sk-...
```

### 3. Lokal starten
```bash
npm run dev
```

App läuft auf http://localhost:3000

---

## Deploy auf Vercel

### 1. GitHub Repo erstellen
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/DEIN-USERNAME/wm-foto-generator.git
git push -u origin main
```

### 2. Vercel verbinden
- vercel.com → New Project → GitHub Repo auswählen
- Framework: Next.js (wird automatisch erkannt)

### 3. Environment Variable setzen
In Vercel → Project Settings → Environment Variables:
- `OPENAI_API_KEY` = dein OpenAI API Key
- `RATE_LIMIT_PER_DAY` = 3 (oder nach Bedarf)

### 4. Deploy
Vercel deployed automatisch bei jedem Git Push.

---

## Länder erweitern

In `src/app/config.ts` einfach neue Länder hinzufügen:

```typescript
export const COUNTRIES: Record<Country, CountryConfig> = {
  de: { ... },
  pt: { ... },
  br: {           // Neu: Brasilien
    flag: '🇧🇷',
    label: 'Brasilien',
    styles: {
      retro: { name: 'Retro', desc: '...', prompt: '...' },
      modern: { name: 'Modern', desc: '...', prompt: '...' },
    }
  }
}
```

Auch den `Country` Type anpassen:
```typescript
export type Country = 'de' | 'pt' | 'br'
```

---

## Rate Limiting

Aktuell: In-Memory (reset bei Server-Neustart).
Für Produktion empfohlen: Vercel KV oder Upstash Redis.

---

## DSGVO

- Fotos werden nur im Request verarbeitet, nie gespeichert
- OpenAI verarbeitet Inputs in den USA (API-Nutzungsbedingungen: 30 Tage Retention)
- Nutzer muss explizit zustimmen vor Upload
- Datenschutz-Seite unter /datenschutz einrichten

## Stack

- Next.js 14 (App Router)
- TypeScript
- OpenAI API (gpt-image-1)
- Vercel (Hosting)
