export type Country = 'de' | 'pt'
export type Style = 'retro' | 'modern'

export interface CountryStyle {
  name: string
  desc: string
  prompt: string
}

export interface CountryConfig {
  flag: string
  label: string
  styles: Record<Style, CountryStyle>
}

const FACE_LOCK = `CRITICAL INSTRUCTION — IMAGE EDITING TASK:
You must preserve the subject's face with absolute fidelity. Keep identical: eye shape and color, nose shape, mouth and lips, jawline, cheekbones, skin tone, beard/stubble, glasses (if present), eyebrows, forehead, and overall facial structure. This is non-negotiable. The person must be 100% recognizable as themselves.
ONLY change: hairstyle, clothing/jersey, and background scenery. Nothing else.`

export const COUNTRIES: Record<Country, CountryConfig> = {
  de: {
    flag: '🇩🇪',
    label: 'Deutschland',
    styles: {
      retro: {
        name: 'Retro / Lustig',
        desc: 'Völler-Ära, 80er-Dauerwelle, Panini-Style',
        prompt: `${FACE_LOCK}

STYLE: 1980s West German football legend (Rudi Völler era).
HAIR: Wild, voluminous curly perm — dark brown, frizzy, shoulder-length. Keep any glasses or beard exactly as-is.
JERSEY: The exact 1988 West Germany Adidas home jersey — pure white base, black V-neck collar, three Adidas black stripes on each sleeve, horizontal black-red-gold stripe band across the chest area, and the Deutscher Fussball-Bund eagle badge on the left chest. This jersey is very specific: white body, black collar, gold/red/black horizontal chest stripe.
BACKGROUND: Old football stadium at night, floodlights beaming down, blurry crowd waving German flags, warm sepia-golden tones, 35mm film grain.
MOOD: Like a classic Panini World Cup sticker — epic, warm-toned, slightly over-exposed.`,
      },
      modern: {
        name: 'Modern / Aktuell',
        desc: 'DFB 2024, cleaner Look, WM-Star',
        prompt: `${FACE_LOCK}

STYLE: Modern German national football team player, 2024/2026 era.
HAIR: Short, clean, contemporary cut. Keep any glasses or beard exactly as-is.
JERSEY: The exact Germany DFB 2024 Adidas home jersey — clean white with very subtle texture, small Adidas logo on right chest, DFB eagle badge on left chest, simple clean design without heavy stripes. Collar is a simple crew neck or small V. No horizontal stripes. Crisp and modern.
BACKGROUND: Modern UEFA/FIFA stadium at night, dramatic blue-white LED floodlights, shallow depth of field, faint German flag colors in bokeh, cinematic atmosphere.
MOOD: Professional, sharp, World Cup ready — like a premium Adidas campaign photo.`,
      },
    },
  },
  pt: {
    flag: '🇵🇹',
    label: 'Portugal',
    styles: {
      retro: {
        name: 'Retro / Lustig',
        desc: 'Eusébio-60er, Vintage, Panini-Style',
        prompt: `${FACE_LOCK}

STYLE: 1966 Portuguese World Cup legend, Eusébio era.
HAIR: Classic 1960s slicked-back or short conservative hairstyle. Keep any glasses or beard exactly as-is.
JERSEY: The exact Portugal 1966 World Cup jersey — deep red/crimson shirt, simple design, white collar, FPF shield badge on left chest. Simple, classic, no Nike or modern branding — this is 1966.
BACKGROUND: Vintage football stadium, grainy black-and-white crowd with warm sepia overlay, film grain, aged photograph aesthetic.
MOOD: Historic, legendary, like a rare 1966 World Cup collectible photo card.`,
      },
      modern: {
        name: 'Modern / Aktuell',
        desc: 'Ronaldo-Glam, Gold-Konfetti, Superstar',
        prompt: `${FACE_LOCK}

STYLE: Modern Portuguese football superstar, Cristiano Ronaldo era.
HAIR: Hair slicked back dramatically, well-groomed. Keep any glasses or beard exactly as-is.
JERSEY: The exact Portugal Nike home jersey 2024 — deep red/crimson, Nike swoosh in gold on right chest, FPF crest (Portuguese coat of arms shield) in gold on left chest, gold number 7 on front, dark green collar trim. Fitted athletic cut.
BACKGROUND: Golden confetti raining from above, blinding stadium floodlights creating dramatic god-rays, crowd in soft bokeh behind.
MOOD: Self-assured, cinematic, pompous in the best way — like they just scored the winning goal and know it.`,
      },
    },
  },
}
