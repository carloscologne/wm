import { NextRequest, NextResponse } from 'next/server'
import OpenAI from 'openai'
import { COUNTRIES, Country, Style } from '../../config'

const rateLimitMap = new Map<string, { count: number; resetAt: number }>()
const RATE_LIMIT = parseInt(process.env.RATE_LIMIT_PER_DAY || '3')

function checkRateLimit(ip: string): boolean {
  const now = Date.now()
  const record = rateLimitMap.get(ip)
  if (!record || now > record.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + 24 * 60 * 60 * 1000 })
    return true
  }
  if (record.count >= RATE_LIMIT) return false
  record.count++
  return true
}

function getClientIp(req: NextRequest): string {
  return (
    req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    req.headers.get('x-real-ip') ||
    'unknown'
  )
}

// Schritt 1: GPT-4o analysiert das Gesicht präzise
async function analyzeFace(openai: OpenAI, imageBase64: string, mimeType: string): Promise<string> {
  const response = await openai.chat.completions.create({
    model: 'gpt-4o',
    max_tokens: 400,
    messages: [
      {
        role: 'user',
        content: [
          {
            type: 'image_url',
            image_url: {
              url: `data:${mimeType};base64,${imageBase64}`,
              detail: 'high',
            },
          },
          {
            type: 'text',
            text: `Describe the facial features of the person in this photo in precise technical detail. This will be used to preserve their identity in an AI image edit. Include:
- Eye shape, size, color, and spacing
- Nose shape and size  
- Mouth and lip shape
- Jawline and chin shape
- Cheekbone structure
- Exact skin tone (e.g. "medium olive", "fair with pink undertones", "deep brown")
- Facial hair: exact style, density, color — or "clean shaven"
- Glasses: frame shape, color, thickness — or "no glasses"
- Overall face shape (oval, round, square, heart, etc.)
- Approximate age appearance
- Any distinctive features (dimples, moles, prominent brow, etc.)

Be precise and factual. Output only the description, no intro or outro text.`,
          },
        ],
      },
    ],
  })

  return response.choices[0]?.message?.content || ''
}

export async function POST(req: NextRequest) {
  try {
    const ip = getClientIp(req)

    if (!checkRateLimit(ip)) {
      return NextResponse.json(
        { error: 'Du hast heute dein Limit erreicht. Morgen wieder!' },
        { status: 429 }
      )
    }

    const formData = await req.formData()
    const file = formData.get('image') as File | null
    const country = formData.get('country') as Country | null
    const style = formData.get('style') as Style | null

    if (!file || !country || !style) {
      return NextResponse.json({ error: 'Fehlende Parameter.' }, { status: 400 })
    }

    const countryConfig = COUNTRIES[country]
    const styleConfig = countryConfig?.styles[style]
    if (!countryConfig || !styleConfig) {
      return NextResponse.json({ error: 'Ungültige Parameter.' }, { status: 400 })
    }

    // Bild zu Base64
    const arrayBuffer = await file.arrayBuffer()
    const imageBase64 = Buffer.from(arrayBuffer).toString('base64')
    const mimeType = file.type || 'image/jpeg'

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

    // Schritt 1: Gesicht analysieren mit GPT-4o
    let faceDescription = ''
    try {
      faceDescription = await analyzeFace(openai, imageBase64, mimeType)
      console.log('Face analysis:', faceDescription)
    } catch (err) {
      console.warn('Face analysis failed, continuing without:', err)
    }

    // Schritt 2: Prompt mit Gesichtsbeschreibung anreichern
    const enrichedPrompt = faceDescription
      ? `${styleConfig.prompt}

EXACT FACE DESCRIPTION — MUST BE PRESERVED IDENTICALLY:
${faceDescription}`
      : styleConfig.prompt

    // Schritt 3: gpt-image-1 mit angereichertem Prompt
    const response = await openai.images.edit({
      model: 'gpt-image-2',
      image: file,
      prompt: enrichedPrompt,
      size: '1024x1024',
      quality: 'high',
    })

    const imageData = response.data?.[0]
    if (!imageData) {
      return NextResponse.json({ error: 'Kein Bild generiert.' }, { status: 500 })
    }

    if (imageData.b64_json) return NextResponse.json({ b64: imageData.b64_json })
    if (imageData.url) return NextResponse.json({ url: imageData.url })

    return NextResponse.json({ error: 'Unbekanntes Antwortformat.' }, { status: 500 })

  } catch (err: unknown) {
    console.error('Generate error:', err)
    const message = err instanceof Error ? err.message : 'Unbekannter Fehler.'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
