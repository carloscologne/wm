import type { Metadata } from 'next'
import Script from 'next/script'
import './globals.css'

export const metadata: Metadata = {
  title: 'WM Foto Generator',
  description: 'Verwandle dein Selfie in einen Fußball-Star — Deutschland oder Portugal, Retro oder Modern.',
  openGraph: {
    title: 'WM Foto Generator',
    description: 'Dein Gesicht. Dein Land. Dein WM-Moment.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body>
        {children}
        <Script src="/_vercel/insights/script.js" strategy="afterInteractive" />
      </body>
    </html>
  )
}
