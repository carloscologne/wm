'use client'

import { useState, useRef, useCallback } from 'react'
import { COUNTRIES, Country, Style } from './config'
import styles from './page.module.css'

type Step = 'country' | 'style' | 'upload' | 'generating' | 'result'

const POLAROIDS = [
  { src: 'https://images.unsplash.com/photo-1543326727-cf6c39e8f84c?w=200&h=240&fit=crop&auto=format', label: '🇩🇪 Retro', rotate: '-6deg' },
  { src: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=200&h=240&fit=crop&auto=format', label: '🇵🇹 Modern', rotate: '2deg' },
  { src: 'https://images.unsplash.com/photo-1517466787929-bc90951d0974?w=200&h=240&fit=crop&auto=format', label: '🇩🇪 Modern', rotate: '-3deg' },
]

export default function Home() {
  const [country, setCountry] = useState<Country | null>(null)
  const [style, setStyle] = useState<Style | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [file, setFile] = useState<File | null>(null)
  const [resultUrl, setResultUrl] = useState<string | null>(null)
  const [step, setStep] = useState<Step>('country')
  const [error, setError] = useState<string | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [isSharing, setIsSharing] = useState(false)
  const [copyDone, setCopyDone] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const track = (event: string, data?: Record<string, string>) => {
    if (typeof window !== 'undefined' && (window as any).va) {
      (window as any).va('event', { name: event, ...data })
    }
  }

  const handleCountry = (c: Country) => {
    setCountry(c); setStyle(null); setStep('style')
    track('country_selected', { country: c })
  }

  const handleStyle = (s: Style) => {
    setStyle(s); setStep('upload')
    track('style_selected', { style: s, country: country || '' })
  }

  const processFile = (f: File) => {
    if (!f.type.startsWith('image/')) return
    setFile(f)
    setPreviewUrl(URL.createObjectURL(f))
    setError(null)
    track('photo_uploaded')
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; if (f) processFile(f)
  }

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); setIsDragging(false)
    const f = e.dataTransfer.files?.[0]; if (f) processFile(f)
  }, [])

  const handleGenerate = async () => {
    if (!file || !country || !style) return
    setStep('generating'); setError(null)
    track('generate_clicked', { country, style })
    try {
      const formData = new FormData()
      formData.append('image', file)
      formData.append('country', country)
      formData.append('style', style)
      const res = await fetch('/api/generate', { method: 'POST', body: formData })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Fehler beim Generieren.')
      if (data.b64) setResultUrl(`data:image/png;base64,${data.b64}`)
      else if (data.url) setResultUrl(data.url)
      setStep('result')
      track('generate_success', { country, style })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unbekannter Fehler.')
      setStep('upload')
      track('generate_error')
    }
  }

  const shareText = () => {
    const flag = country ? COUNTRIES[country].flag : '⚽'
    return `Ich bin jetzt WM-Star! ${flag} Mach dir auch dein WM-Bild auf wmmoment.de 🔥`
  }

  const handleWhatsApp = () => {
    const text = encodeURIComponent(shareText())
    window.open(`https://wa.me/?text=${text}`, '_blank')
    track('share_whatsapp')
  }

  const handleInstagram = async () => {
    // Instagram hat keine direkte Share-API — wir kopieren Text + triggern Download
    if (resultUrl) {
      const a = document.createElement('a')
      a.href = resultUrl
      a.download = 'mein-wm-moment.png'
      a.click()
    }
    await navigator.clipboard.writeText(shareText()).catch(() => {})
    alert('Bild wurde heruntergeladen! Text kopiert — einfach in Instagram einfügen.')
    track('share_instagram')
  }

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(window.location.href)
    setCopyDone(true)
    setTimeout(() => setCopyDone(false), 2000)
    track('share_copy_link')
  }

  const handleNativeShare = async () => {
    if (isSharing) return
    setIsSharing(true)
    try {
      if (navigator.share) {
        await navigator.share({ title: 'Mein WM-Moment', text: shareText(), url: window.location.href })
        track('share_native')
      }
    } catch { /* user cancelled */ }
    finally { setIsSharing(false) }
  }

  const handleNewStyle = () => {
    setResultUrl(null); setStep('country')
    track('new_image_clicked')
  }

  const countryConfig = country ? COUNTRIES[country] : null

  return (
    <>
      <main className={styles.main}>
        <div className={styles.container}>

          {/* Hero */}
          <header className={styles.hero}>
            <div className={styles.polaroidRow}>
              {POLAROIDS.map((p, i) => (
                <div key={i} className={styles.polaroid} style={{ '--rotate': p.rotate } as React.CSSProperties}>
                  <img src={p.src} alt={p.label} className={styles.polaroidImg} />
                  <span className={styles.polaroidLabel}>{p.label}</span>
                </div>
              ))}
            </div>
            <div className={styles.badge}>⚽ WM 2026</div>
            <h1 className={styles.title}>Dein WM-Moment</h1>
            <p className={styles.intro}>
              Lad dein Selfie hoch — wir machen daraus ein WM-Bild mit Herz für dein Land. Deutschland oder Portugal. Retro-Kult oder moderner Star. Einfach. Kostenlos. Lustig.
            </p>
          </header>

          {/* Land */}
          {(step === 'country' || step === 'style' || step === 'upload') && (
            <section className={styles.section}>
              <p className={styles.sectionLabel}><span className={styles.stepNum}>1</span> Dein Land</p>
              <div className={styles.countryGrid}>
                {(Object.entries(COUNTRIES) as [Country, typeof COUNTRIES[Country]][]).map(([key, cfg]) => (
                  <button key={key}
                    className={`${styles.countryBtn} ${country === key ? styles.countryBtnActive : ''} ${styles[`country_${key}`]}`}
                    onClick={() => handleCountry(key)}>
                    <span className={styles.flag}>{cfg.flag}</span>
                    <span className={styles.countryName}>{cfg.label}</span>
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* Style */}
          {(step === 'style' || step === 'upload') && countryConfig && (
            <section className={styles.section}>
              <p className={styles.sectionLabel}><span className={styles.stepNum}>2</span> Dein Style</p>
              <div className={styles.styleGrid}>
                {(Object.entries(countryConfig.styles) as [Style, typeof countryConfig.styles[Style]][]).map(([key, s]) => (
                  <button key={key}
                    className={`${styles.styleBtn} ${style === key ? styles.styleBtnActive : ''}`}
                    onClick={() => handleStyle(key)}>
                    <span className={styles.styleName}>{s.name}</span>
                    <span className={styles.styleDesc}>{s.desc}</span>
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* Upload */}
          {step === 'upload' && style && (
            <section className={styles.section}>
              <p className={styles.sectionLabel}><span className={styles.stepNum}>3</span> Dein Selfie</p>
              <div
                className={`${styles.uploadArea} ${isDragging ? styles.uploadDragging : ''} ${previewUrl ? styles.uploadHasPreview : ''}`}
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}>
                <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className={styles.fileInput} />
                {previewUrl
                  ? <img src={previewUrl} alt="Vorschau" className={styles.previewImg} />
                  : <div className={styles.uploadPlaceholder}>
                      <span className={styles.uploadIcon}>📷</span>
                      <p>Foto hochladen oder hier hinziehen</p>
                      <p className={styles.uploadHint}>JPG, PNG, WEBP — frontal, gute Beleuchtung</p>
                    </div>
                }
              </div>
              {previewUrl && (
                <button className={styles.changePhoto} onClick={() => fileInputRef.current?.click()}>Anderes Foto wählen</button>
              )}
              {error && <p className={styles.error}>{error}</p>}
              <button className={styles.generateBtn} onClick={handleGenerate} disabled={!file}>Jetzt generieren →</button>
              <p className={styles.dsgvoNote}>
                Dein Foto wird einmalig an OpenAI übermittelt und nicht gespeichert.{' '}
                <a href="/datenschutz" className={styles.dsgvoLink}>Datenschutz</a>
              </p>
            </section>
          )}

          {/* Generating */}
          {step === 'generating' && (
            <section className={styles.loadingSection}>
              <div className={styles.spinner} />
              <p className={styles.loadingText}>Dein WM-Bild wird generiert…</p>
              <p className={styles.loadingSubtext}>Das dauert ca. 15–30 Sekunden</p>
            </section>
          )}

          {/* Result */}
          {step === 'result' && resultUrl && (
            <section className={styles.resultSection}>
              <div className={styles.resultBadge}>
                {countryConfig?.flag} {countryConfig?.label} — {style && countryConfig?.styles[style].name}
              </div>
              <img src={resultUrl} alt="Dein WM-Bild" className={styles.resultImg} />

              {/* Download */}
              <a href={resultUrl} download="mein-wm-moment.png" className={styles.downloadBtn}>
                ↓ Bild herunterladen
              </a>

              {/* Share Buttons */}
              <div className={styles.shareSection}>
                <p className={styles.shareLabel}>Teilen</p>
                <div className={styles.shareGrid}>

                  {/* WhatsApp */}
                  <button className={`${styles.shareBtn} ${styles.shareBtnWA}`} onClick={handleWhatsApp}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                    WhatsApp
                  </button>

                  {/* Instagram */}
                  <button className={`${styles.shareBtn} ${styles.shareBtnIG}`} onClick={handleInstagram}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                    </svg>
                    Instagram
                  </button>

                  {/* Link kopieren */}
                  <button className={`${styles.shareBtn} ${styles.shareBtnLink}`} onClick={handleCopyLink}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                      <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                      <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
                    </svg>
                    {copyDone ? '✓ Kopiert!' : 'Link kopieren'}
                  </button>

                  {/* Native Share (Mobile) */}
                  {typeof navigator !== 'undefined' && 'share' in navigator && (
                    <button className={`${styles.shareBtn} ${styles.shareBtnNative}`} onClick={handleNativeShare} disabled={isSharing}>
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                        <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
                      </svg>
                      Mehr
                    </button>
                  )}
                </div>
              </div>

              <button className={styles.resetBtn} onClick={handleNewStyle}>Neues Bild erstellen</button>
            </section>
          )}

        </div>
      </main>

      {/* Footer */}
      <footer className={styles.footer}>
        <p className={styles.footerText}>
          Eine verrückte Idee von <a href="https://oneworx.de" target="_blank" rel="noopener" className={styles.footerLink}>Carlos @ ONEWORX</a>
        </p>
        <p className={styles.footerSub}>
          KI-Readiness für dein Unternehmen? → <a href="https://kiwasgeht.de" target="_blank" rel="noopener" className={styles.footerLink}>kiwasgeht.de</a>
        </p>
        <p className={styles.footerOctopus}>🐙</p>
      </footer>
    </>
  )
}
