import headerAsset from "@/assets/header-wm.jpg.asset.json";

export function Hero() {
  return (
    <header className="text-center pt-4 pb-8">
      <div className="mx-auto max-w-2xl rounded-2xl overflow-hidden shadow-2xl">
        <img
          src={headerAsset.url}
          alt="WM-Stadion Atmosphäre"
          className="w-full h-auto object-cover"
          width={1536}
          height={640}
        />
      </div>
      <div className="mt-8 px-4">
        <h1 className="text-4xl md:text-6xl font-black tracking-tight text-cream">
          Dein <span className="text-red-500">WM-Moment</span>
        </h1>
        <p className="mt-3 text-base md:text-lg text-cream/70">
          Dein Gesicht. Dein Land. Deine Legende.
        </p>
      </div>
    </header>
  );
}