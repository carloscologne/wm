import { COUNTRIES } from "@/lib/countries";
import { StepBadge } from "./StepBadge";

export function CountryStep({
  selected,
  onSelect,
}: {
  selected: string | null;
  onSelect: (id: string) => void;
}) {
  return (
    <section className="bg-cream rounded-2xl p-5 md:p-6 shadow-lg">
      <StepBadge n={1} title="Wähle dein Land" />
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {COUNTRIES.map((c) => {
          const active = selected === c.id;
          return (
            <button
              key={c.id}
              onClick={() => onSelect(c.id)}
              className={`flex flex-col items-center justify-center rounded-xl py-5 px-3 border-2 transition-all ${
                active
                  ? "border-red-500 bg-red-50 scale-[1.02]"
                  : "border-ink/10 bg-white hover:border-ink/30"
              }`}
            >
              <span className="text-5xl md:text-6xl leading-none">{c.flag}</span>
              <span className="mt-2 font-semibold text-ink text-sm md:text-base">
                {c.label}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}