import { trackEvent } from "@/lib/analytics";
import { useEffect, useState } from "react";

async function addWatermark(srcUrl: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext("2d");
        if (!ctx) return resolve(srcUrl);
        ctx.drawImage(img, 0, 0);

        const text = "oneworx.de/wm";
        const fontSize = Math.max(14, Math.round(canvas.width * 0.018));
        ctx.font = `600 ${fontSize}px ui-sans-serif, system-ui, -apple-system, sans-serif`;
        ctx.textBaseline = "bottom";
        ctx.textAlign = "right";
        const padding = Math.round(fontSize * 0.9);
        const x = canvas.width - padding;
        const y = canvas.height - padding;

        ctx.shadowColor = "rgba(0,0,0,0.55)";
        ctx.shadowBlur = Math.max(2, fontSize * 0.25);
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 1;
        ctx.fillStyle = "rgba(255,255,255,0.78)";
        ctx.fillText(text, x, y);

        resolve(canvas.toDataURL("image/png"));
      } catch (e) {
        reject(e);
      }
    };
    img.onerror = reject;
    img.src = srcUrl;
  });
}

export function Result({
  imageUrl,
  countryId,
  style,
  onReset,
}: {
  imageUrl: string;
  countryId: string;
  style: string;
  onReset: () => void;
}) {
  const [finalUrl, setFinalUrl] = useState(imageUrl);

  useEffect(() => {
    let cancelled = false;
    setFinalUrl(imageUrl);
    addWatermark(imageUrl)
      .then((url) => {
        if (!cancelled) setFinalUrl(url);
      })
      .catch(() => {
        // fall back to original on error
      });
    return () => {
      cancelled = true;
    };
  }, [imageUrl]);

  async function download() {
    trackEvent("download_clicked", { countryId, style });
    const a = document.createElement("a");
    a.href = finalUrl;
    a.download = `wm-moment-${countryId}-${style}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function share() {
    trackEvent("share_clicked", { countryId, style });
    try {
      const res = await fetch(finalUrl);
      const blob = await res.blob();
      const file = new File([blob], `wm-moment-${countryId}.png`, { type: "image/png" });
      const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
      if (nav.canShare?.({ files: [file] }) && navigator.share) {
        await navigator.share({
          files: [file],
          title: "Dein WM-Moment",
          text: "Mein WM-Moment 🏆",
        });
        return;
      }
    } catch {
      // fall through
    }
    try {
      await navigator.clipboard.writeText(window.location.href);
      alert("Link kopiert!");
    } catch {
      alert("Teilen nicht möglich.");
    }
  }

  return (
    <section className="bg-cream rounded-2xl p-5 md:p-6 shadow-lg">
      <h2 className="text-2xl font-black text-ink mb-4">Dein WM-Moment 🏆</h2>
      <div className="rounded-xl overflow-hidden bg-black/5 mb-4">
        <img src={finalUrl} alt="Dein WM-Moment" className="w-full h-auto" />
      </div>
      <div className="flex flex-col sm:flex-row gap-2">
        <button
          onClick={download}
          className="flex-1 rounded-xl bg-black text-cream font-bold py-3 hover:bg-black/80"
        >
          ⬇ Download
        </button>
        <button
          onClick={share}
          className="flex-1 rounded-xl bg-red-500 text-white font-bold py-3 hover:bg-red-600"
        >
          ↗ Teilen
        </button>
      </div>
      <button
        onClick={onReset}
        className="mt-3 w-full rounded-xl border-2 border-ink/20 text-ink font-semibold py-3 hover:bg-white"
      >
        Neues Bild erstellen
      </button>
    </section>
  );
}