export function Footer() {
  return (
    <footer className="text-center text-xs text-cream/60 py-8 px-4 leading-relaxed">
      <p>
        Eine verrückte Idee von Carlos @{" "}
        <a
          href="https://oneworx.de"
          target="_blank"
          rel="noreferrer"
          className="underline hover:text-cream"
        >
          ONEWORX
        </a>
      </p>
      <p className="mt-1">
        KI-Readiness →{" "}
        <a
          href="https://kiwasgeht.de"
          target="_blank"
          rel="noreferrer"
          className="underline hover:text-cream"
        >
          kiwasgeht.de
        </a>{" "}
        🐙
      </p>
    </footer>
  );
}