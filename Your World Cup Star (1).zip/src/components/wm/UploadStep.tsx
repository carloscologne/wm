import { useRef, useState } from "react";
import { StepBadge } from "./StepBadge";

export function UploadStep({
  file,
  onFile,
}: {
  file: File | null;
  onFile: (f: File | null) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const previewUrl = file ? URL.createObjectURL(file) : null;

  return (
    <section className="bg-cream rounded-2xl p-5 md:p-6 shadow-lg">
      <StepBadge n={3} title="Lade dein Selfie hoch" />

      <div
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          const f = e.dataTransfer.files?.[0];
          if (f) onFile(f);
        }}
        className={`cursor-pointer rounded-xl border-2 border-dashed p-6 text-center transition-colors ${
          dragOver ? "border-red-500 bg-red-50" : "border-ink/20 bg-white hover:border-ink/40"
        }`}
      >
        {previewUrl ? (
          <div className="flex flex-col items-center gap-3">
            <img
              src={previewUrl}
              alt="Dein Selfie"
              className="w-32 h-32 object-cover rounded-lg shadow"
            />
            <div className="text-sm text-ink/70">{file?.name}</div>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onFile(null);
              }}
              className="text-xs text-red-500 underline"
            >
              Anderes Bild wählen
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2 text-ink/70">
            <div className="text-3xl">📸</div>
            <div className="font-semibold text-ink">Foto hierher ziehen</div>
            <div className="text-sm">oder klicken zum Auswählen (JPG, PNG, WEBP)</div>
          </div>
        )}
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="hidden"
          onChange={(e) => onFile(e.target.files?.[0] ?? null)}
        />
      </div>

      <p className="mt-3 text-xs text-ink/50">
        Dein Foto wird einmalig an OpenAI übermittelt und nicht gespeichert.{" "}
        <a href="/datenschutz" className="underline hover:text-ink">
          Datenschutz
        </a>
        .
      </p>
    </section>
  );
}