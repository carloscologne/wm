import { getCountry } from "@/lib/countries";
import { StepBadge } from "./StepBadge";

export function StyleStep({
  countryId,
  selected,
  onSelect,
}: {
  countryId: string;
  selected: "retro" | "modern" | null;
  onSelect: (s: "retro" | "modern") => void;
}) {
  const country = getCountry(countryId);
  if (!country) return null;
  const keys: ("retro" | "modern")[] = ["retro", "modern"];

  return (
    <section className="bg-cream rounded-2xl p-5 md:p-6 shadow-lg">
      <StepBadge n={2} title="Wähle den Style" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {keys.map((k) => {
          const s = country.styles[k];
          const active = selected === k;
          return (
            <button
              key={k}
              onClick={() => onSelect(k)}
              className={`text-left rounded-xl p-4 border-2 transition-all ${
                active
                  ? "border-red-500 bg-red-50"
                  : "border-ink/10 bg-white hover:border-ink/30"
              }`}
            >
              <div className="font-bold text-ink">{s.name}</div>
              <div className="text-sm text-ink/60 mt-1">{s.desc}</div>
            </button>
          );
        })}
      </div>
    </section>
  );
}