export function StepBadge({ n, title }: { n: number; title: string }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <div className="w-8 h-8 rounded-full bg-black text-cream flex items-center justify-center font-bold text-sm">
        {n}
      </div>
      <h2 className="text-xl font-bold text-ink">{title}</h2>
    </div>
  );
}