const LIMIT = 3;
const buckets = new Map<string, { day: string; count: number }>();

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

export function checkRateLimit(ip: string): { ok: boolean; remaining: number } {
  const day = today();
  const cur = buckets.get(ip);
  if (!cur || cur.day !== day) {
    return { ok: true, remaining: LIMIT };
  }
  return { ok: cur.count < LIMIT, remaining: Math.max(0, LIMIT - cur.count) };
}

export function consumeRateLimit(ip: string): { ok: boolean; remaining: number } {
  const day = today();
  const cur = buckets.get(ip);
  if (!cur || cur.day !== day) {
    buckets.set(ip, { day, count: 1 });
    return { ok: true, remaining: LIMIT - 1 };
  }
  if (cur.count >= LIMIT) return { ok: false, remaining: 0 };
  cur.count += 1;
  return { ok: true, remaining: LIMIT - cur.count };
}

export function getClientIp(request: Request): string {
  const xff = request.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim();
  return request.headers.get("x-real-ip") ?? "unknown";
}

export const DAILY_LIMIT = LIMIT;