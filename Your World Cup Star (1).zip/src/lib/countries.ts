export interface CountryStyle {
  name: string;
  desc: string;
  prompt: string;
}

export interface Country {
  id: string;
  flag: string;
  label: string;
  styles: {
    retro: CountryStyle;
    modern: CountryStyle;
  };
}

export const FACE_DESCRIPTION_PLACEHOLDER = "[insert face description here]";

export const COUNTRIES: Country[] = [
  {
    id: "de",
    flag: "🇩🇪",
    label: "Deutschland",
    styles: {
      retro: {
        name: "Retro / Lustig",
        desc: "1980er West-Germany Legende",
        prompt: `CRITICAL INSTRUCTION: Preserve the subject's face with absolute fidelity. Keep identical: eye shape and color, nose, mouth, jawline, cheekbones, skin tone, beard/stubble, glasses if present. ONLY change hairstyle, clothing, background.

STYLE: 1980s West German football legend (Rudi Völler era).

HAIR: Wild voluminous curly perm, dark brown, frizzy, shoulder-length. Keep glasses/beard.

JERSEY: Exact 1988 West Germany Adidas home jersey — pure white, black V-neck collar, three black Adidas stripes on sleeves, horizontal black-red-gold stripe band across chest, Deutscher Fussball-Bund eagle badge on left chest.

BACKGROUND: Old stadium at night, floodlights, blurry crowd with German flags, warm sepia-golden tones, 35mm film grain.

MOOD: Classic Panini World Cup sticker — epic, warm-toned, slightly over-exposed.

EXACT FACE DESCRIPTION — MUST BE PRESERVED:

[insert face description here]`,
      },
      modern: {
        name: "Modern / Aktuell",
        desc: "DFB 2024/2026 Star",
        prompt: `CRITICAL INSTRUCTION: Preserve the subject's face with absolute fidelity. Keep identical: eye shape and color, nose, mouth, jawline, cheekbones, skin tone, beard/stubble, glasses if present. ONLY change hairstyle, clothing, background.

STYLE: Modern German national team player, 2024/2026 era.

HAIR: Short, clean, contemporary. Keep glasses/beard.

JERSEY: Germany DFB 2024 Adidas home jersey — clean white, subtle texture, small Adidas logo right chest, DFB eagle badge left chest, simple crew or small V neck. No horizontal stripes. Crisp and modern.

BACKGROUND: Modern UEFA/FIFA stadium at night, blue-white LED floodlights, faint German flag colors in bokeh, cinematic.

MOOD: Professional, sharp, World Cup ready — premium Adidas campaign photo.

EXACT FACE DESCRIPTION — MUST BE PRESERVED:

[insert face description here]`,
      },
    },
  },
  {
    id: "pt",
    flag: "🇵🇹",
    label: "Portugal",
    styles: {
      retro: {
        name: "Retro / Lustig",
        desc: "1966 Eusébio Era",
        prompt: `CRITICAL INSTRUCTION: Preserve the subject's face with absolute fidelity. Keep identical: eye shape and color, nose, mouth, jawline, cheekbones, skin tone, beard/stubble, glasses if present. ONLY change hairstyle, clothing, background.

STYLE: 1966 Portuguese World Cup legend, Eusébio era.

HAIR: Classic 1960s slicked-back or short conservative style. Keep glasses/beard.

JERSEY: Portugal 1966 World Cup jersey — deep red/crimson, white collar, FPF shield badge left chest. Simple, classic, NO Nike or modern branding.

BACKGROUND: Vintage stadium, grainy black-and-white crowd, warm sepia overlay, film grain, aged photograph aesthetic.

MOOD: Historic, legendary — rare 1966 World Cup collectible photo card.

EXACT FACE DESCRIPTION — MUST BE PRESERVED:

[insert face description here]`,
      },
      modern: {
        name: "Modern / Aktuell",
        desc: "Ronaldo Era Superstar",
        prompt: `CRITICAL INSTRUCTION: Preserve the subject's face with absolute fidelity. Keep identical: eye shape and color, nose, mouth, jawline, cheekbones, skin tone, beard/stubble, glasses if present. ONLY change hairstyle, clothing, background.

STYLE: Modern Portuguese superstar, Cristiano Ronaldo era.

HAIR: Slicked back dramatically, well-groomed. Keep glasses/beard.

JERSEY: Portugal Nike home jersey 2024 — deep red/crimson, gold Nike swoosh right chest, FPF crest in gold left chest, gold number 7 front, dark green collar trim. Fitted athletic cut.

BACKGROUND: Golden confetti raining down, blinding stadium floodlights, dramatic god-rays, crowd in soft bokeh.

MOOD: Self-assured, cinematic, pompous in the best way — just scored the winner and knows it.

EXACT FACE DESCRIPTION — MUST BE PRESERVED:

[insert face description here]`,
      },
    },
  },
  {
    id: "br",
    flag: "🇧🇷",
    label: "Brasilien",
    styles: {
      retro: {
        name: "Retro / Lustig",
        desc: "1970 Pelé Era",
        prompt: `CRITICAL INSTRUCTION: Preserve the subject's face with absolute fidelity. Keep identical: eye shape and color, nose, mouth, jawline, cheekbones, skin tone, beard/stubble, glasses if present. ONLY change hairstyle, clothing, background.

STYLE: 1970 Brazilian World Cup legend, Pelé era.

HAIR: Natural afro or short classic 1970s style. Keep glasses/beard.

JERSEY: Exact Brazil 1970 World Cup jersey — bright canary yellow, deep green V-collar, CBD badge (old Brazilian football federation crest) on left chest, no sponsor, simple classic design.

BACKGROUND: Vintage Mexican stadium 1970, warm afternoon sunlight, grainy crowd, faded film colors, golden haze.

MOOD: The greatest football team ever — joyful, legendary, sun-drenched. Like a rare 1970 Panini sticker.

EXACT FACE DESCRIPTION — MUST BE PRESERVED:

[insert face description here]`,
      },
      modern: {
        name: "Modern / Aktuell",
        desc: "Vinicius / Neymar Era",
        prompt: `CRITICAL INSTRUCTION: Preserve the subject's face with absolute fidelity. Keep identical: eye shape and color, nose, mouth, jawline, cheekbones, skin tone, beard/stubble, glasses if present. ONLY change hairstyle, clothing, background.

STYLE: Modern Brazilian football superstar, Vinicius Jr / Neymar era.

HAIR: Modern fade or creative styled cut. Keep glasses/beard.

JERSEY: Brazil Nike home jersey 2024 — bright canary yellow, CBF crest in gold/green on left chest, green Nike swoosh on right, green collar, fitted athletic cut.

BACKGROUND: Modern stadium at night, green-yellow LED atmosphere, carnival confetti, electric crowd energy.

MOOD: Explosive, joyful, showboating — samba football at its finest.

EXACT FACE DESCRIPTION — MUST BE PRESERVED:

[insert face description here]`,
      },
    },
  },
];

export function getCountry(id: string): Country | undefined {
  return COUNTRIES.find((c) => c.id === id);
}