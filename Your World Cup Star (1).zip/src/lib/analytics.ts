export function trackEvent(event: string, props: Record<string, unknown> = {}) {
  try {
    void fetch("/api/track", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event, props }),
      keepalive: true,
    });
  } catch {
    // ignore
  }
}