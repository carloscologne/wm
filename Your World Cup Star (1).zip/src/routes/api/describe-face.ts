import { createFileRoute } from "@tanstack/react-router";

const FACE_PROMPT =
  "Describe the facial features of the person in this photo in precise technical detail for AI image editing. Include: eye shape/color/spacing, nose shape, mouth/lip shape, jawline, cheekbone structure, exact skin tone, facial hair (style/density/color or clean shaven), glasses (frame shape/color or none), face shape, age appearance, distinctive features. Output only the description, no intro text.";

export const Route = createFileRoute("/api/describe-face")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const { imageDataUrl } = (await request.json()) as { imageDataUrl: string };
        if (!imageDataUrl?.startsWith("data:image/")) {
          return new Response("Invalid image", { status: 400 });
        }

        const upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "google/gemini-3-flash-preview",
            messages: [
              {
                role: "user",
                content: [
                  { type: "text", text: FACE_PROMPT },
                  { type: "image_url", image_url: { url: imageDataUrl } },
                ],
              },
            ],
          }),
        });

        if (!upstream.ok) {
          const text = await upstream.text();
          return new Response(text || "Upstream error", { status: upstream.status });
        }

        const json = (await upstream.json()) as {
          choices?: { message?: { content?: string } }[];
        };
        const description = json.choices?.[0]?.message?.content?.trim() ?? "";
        return Response.json({ description });
      },
    },
  },
});