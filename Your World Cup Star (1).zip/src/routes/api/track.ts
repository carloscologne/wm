import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/track")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const body = await request.json();
          console.log("[track]", JSON.stringify(body));
        } catch {
          // ignore
        }
        return new Response(null, { status: 204 });
      },
    },
  },
});