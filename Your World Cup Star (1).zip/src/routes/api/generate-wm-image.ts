import { createFileRoute } from "@tanstack/react-router";
import { COUNTRIES, FACE_DESCRIPTION_PLACEHOLDER } from "@/lib/countries";
import { checkRateLimit, consumeRateLimit, getClientIp } from "@/lib/rate-limit";

export const Route = createFileRoute("/api/generate-wm-image")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const ip = getClientIp(request);
        const pre = checkRateLimit(ip);
        if (!pre.ok) {
          return Response.json(
            { error: "Tageslimit erreicht. Komm morgen wieder!" },
            { status: 429 },
          );
        }

        const { countryId, style, imageDataUrl, description } = (await request.json()) as {
          countryId: string;
          style: "retro" | "modern";
          imageDataUrl: string;
          description: string;
        };

        const country = COUNTRIES.find((c) => c.id === countryId);
        if (!country || (style !== "retro" && style !== "modern")) {
          return new Response("Invalid country/style", { status: 400 });
        }
        if (!imageDataUrl?.startsWith("data:image/")) {
          return new Response("Invalid image", { status: 400 });
        }

        const template = country.styles[style].prompt;
        const prompt = template.replace(
          FACE_DESCRIPTION_PLACEHOLDER,
          description?.trim() || "(no description available — preserve face exactly as in input image)",
        );

        const upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "google/gemini-3-pro-image-preview",
            messages: [
              {
                role: "user",
                content: [
                  { type: "text", text: prompt },
                  { type: "image_url", image_url: { url: imageDataUrl } },
                ],
              },
            ],
          }),
        });

        if (!upstream.ok) {
          const text = await upstream.text();
          console.error("[generate-wm-image] upstream", upstream.status, text);
          if (upstream.status === 429) {
            return Response.json(
              { error: "AI Gateway Rate Limit. Bitte kurz warten." },
              { status: 429 },
            );
          }
          if (upstream.status === 402) {
            return Response.json(
              { error: "AI Gateway Guthaben aufgebraucht." },
              { status: 402 },
            );
          }
          return new Response(text || "Upstream error", { status: upstream.status });
        }

        const json = (await upstream.json()) as {
          choices?: {
            message?: {
              images?: { image_url?: { url?: string } | string }[];
            };
          }[];
        };
        const imgs = json.choices?.[0]?.message?.images;
        const first = imgs?.[0]?.image_url;
        const url = typeof first === "string" ? first : first?.url;
        if (!url) {
          console.error("[generate-wm-image] no image in response", JSON.stringify(json).slice(0, 500));
          return new Response("No image returned", { status: 502 });
        }

        let b64 = "";
        let mimeType = "image/png";
        const m = url.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
        if (m) {
          mimeType = m[1];
          b64 = m[2];
        } else {
          const r = await fetch(url);
          const buf = Buffer.from(await r.arrayBuffer());
          b64 = buf.toString("base64");
          mimeType = r.headers.get("content-type") ?? "image/png";
        }

        consumeRateLimit(ip);
        return Response.json({ imageBase64: b64, mimeType });
      },
    },
  },
});