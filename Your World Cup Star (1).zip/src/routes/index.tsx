import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Hero } from "@/components/wm/Hero";
import { CountryStep } from "@/components/wm/CountryStep";
import { StyleStep } from "@/components/wm/StyleStep";
import { UploadStep } from "@/components/wm/UploadStep";
import { Result } from "@/components/wm/Result";
import { Footer } from "@/components/wm/Footer";
import { trackEvent } from "@/lib/analytics";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dein WM-Moment — Werde zur WM-Legende" },
      { name: "description", content: "Dein Gesicht. Dein Land. Deine Legende. Upload dein Selfie und werde zum WM-Star." },
      { property: "og:title", content: "Dein WM-Moment" },
      { property: "og:description", content: "Dein Gesicht. Dein Land. Deine Legende." },
    ],
  }),
  component: Index,
});

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(file);
  });
}

function extractErrorMessage(raw: string): string {
  if (!raw) return "";
  try {
    const j = JSON.parse(raw);
    const candidate =
      (typeof j?.error === "string" && j.error) ||
      (typeof j?.error?.message === "string" && j.error.message) ||
      (typeof j?.message === "string" && j.message) ||
      "";
    return candidate || raw;
  } catch {
    return raw;
  }
}

function Index() {
  const [countryId, setCountryId] = useState<string | null>(null);
  const [style, setStyle] = useState<"retro" | "modern" | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);

  useEffect(() => {
    if (countryId) trackEvent("country_selected", { countryId });
  }, [countryId]);
  useEffect(() => {
    if (style && countryId) trackEvent("style_selected", { countryId, style });
  }, [style, countryId]);

  async function generate() {
    if (!countryId || !style || !file) return;
    setError(null);
    setLoading(true);
    trackEvent("generate_clicked", { countryId, style });
    try {
      const imageDataUrl = await readAsDataUrl(file);
      const descRes = await fetch("/api/describe-face", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageDataUrl }),
      });
      if (!descRes.ok) {
        const t = await descRes.text();
        throw new Error(extractErrorMessage(t) || "Gesichtsanalyse fehlgeschlagen");
      }
      const { description } = (await descRes.json()) as { description: string };

      const genRes = await fetch("/api/generate-wm-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ countryId, style, imageDataUrl, description }),
      });
      if (!genRes.ok) {
        const t = await genRes.text();
        throw new Error(extractErrorMessage(t) || "Generierung fehlgeschlagen");
      }
      const { imageBase64, mimeType } = (await genRes.json()) as {
        imageBase64: string;
        mimeType: string;
      };
      setResultUrl(`data:${mimeType};base64,${imageBase64}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Etwas ist schiefgegangen.");
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setResultUrl(null);
    setFile(null);
    setStyle(null);
    setCountryId(null);
    setError(null);
  }

  const canGenerate = countryId && style && file && !loading;

  return (
    <div className="min-h-screen bg-[#0e0e0e] text-cream">
      <div className="max-w-2xl mx-auto px-4 pb-4">
        <Hero />

        {resultUrl ? (
          <Result
            imageUrl={resultUrl}
            countryId={countryId!}
            style={style!}
            onReset={reset}
          />
        ) : loading ? (
          <div className="bg-cream rounded-2xl p-10 text-center shadow-lg">
            <div className="inline-block w-12 h-12 border-4 border-ink/20 border-t-red-500 rounded-full animate-spin" />
            <p className="mt-4 font-semibold text-ink">
              Dein WM-Bild wird generiert…
            </p>
            <p className="text-sm text-ink/60 mt-1">ca. 15–30 Sekunden</p>
          </div>
        ) : (
          <div className="space-y-4">
            <CountryStep selected={countryId} onSelect={setCountryId} />
            {countryId && (
              <StyleStep
                countryId={countryId}
                selected={style}
                onSelect={setStyle}
              />
            )}
            {countryId && style && (
              <UploadStep file={file} onFile={setFile} />
            )}
            {error && (
              <div className="bg-red-500/20 border border-red-500/40 text-red-100 rounded-xl p-3 text-sm">
                {error}
              </div>
            )}
            <button
              disabled={!canGenerate}
              onClick={generate}
              className="w-full rounded-2xl bg-red-500 text-white font-black text-lg py-4 shadow-lg disabled:opacity-30 disabled:cursor-not-allowed hover:bg-red-600 transition"
            >
              Jetzt generieren →
            </button>
          </div>
        )}

        <Footer />
      </div>
    </div>
  );
}
