import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/datenschutz")({
  head: () => ({
    meta: [
      { title: "Datenschutz — Dein WM-Moment" },
      { name: "description", content: "Datenschutzhinweise zu Dein WM-Moment." },
    ],
  }),
  component: Datenschutz,
});

function Datenschutz() {
  return (
    <div className="min-h-screen bg-[#0e0e0e] text-cream">
      <div className="max-w-2xl mx-auto px-4 py-12">
        <Link to="/" className="text-sm text-cream/60 underline hover:text-cream">
          ← zurück
        </Link>
        <article className="bg-cream text-ink rounded-2xl p-6 md:p-8 shadow-lg mt-4 prose prose-sm max-w-none">
          <h1 className="text-3xl font-black mb-4">Datenschutz</h1>

          <h2 className="font-bold mt-6 mb-2">Verarbeitung deines Fotos</h2>
          <p>
            Das Foto, das du hochlädst, wird einmalig an die OpenAI-API
            (über das Lovable AI Gateway) übermittelt, um daraus ein
            stilisiertes WM-Bild zu erzeugen. Wir speichern dein Foto
            nicht. Sowohl die Gesichtsbeschreibung als auch das
            generierte Bild werden ausschließlich für deine aktuelle
            Anfrage verarbeitet und anschließend verworfen.
          </p>

          <h2 className="font-bold mt-6 mb-2">Rate Limiting</h2>
          <p>
            Zur Begrenzung des Missbrauchs zählen wir die Anzahl
            erfolgreicher Generierungen pro IP-Adresse (max. 3 pro Tag)
            im Arbeitsspeicher. Diese Daten werden nicht dauerhaft
            gespeichert.
          </p>

          <h2 className="font-bold mt-6 mb-2">Drittanbieter</h2>
          <p>
            Bei der Generierung wird OpenAI als Subprozessor genutzt.
            Details: openai.com/policies/privacy-policy
          </p>

          <h2 className="font-bold mt-6 mb-2">Kontakt</h2>
          <p>
            Eine verrückte Idee von Carlos @ ONEWORX —{" "}
            <a href="https://oneworx.de" className="underline">
              oneworx.de
            </a>
            .
          </p>
        </article>
      </div>
    </div>
  );
}