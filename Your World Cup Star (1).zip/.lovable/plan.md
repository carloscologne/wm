# Dein WM-Moment — Implementation Plan

A TanStack Start app that turns a selfie into a WM football star portrait using Lovable AI Gateway (Gemini for face description + gpt-image-2 for image edit).

## User Flow
Hero → Step 1: Country → Step 2: Style (Retro / Modern) → Step 3: Upload selfie → Generate → Result with download + share + "noch eins" button.

## Data-driven country config
`src/lib/countries.ts` exports `COUNTRIES: Country[]` with shape:
```ts
interface Country {
  id: string; flag: string; label: string;
  styles: {
    retro:  { name: string; desc: string; prompt: string };
    modern: { name: string; desc: string; prompt: string };
  };
}
```
Seed: 🇩🇪 Deutschland, 🇵🇹 Portugal, 🇧🇷 Brasilien — all 4 prompts (DE retro/modern, PT retro/modern from earlier message; BR retro/modern from latest message) stored verbatim with `[insert face description here]` placeholder.

Adding a country = push one object. UI never changes.

## UI components (`src/components/wm/`)
- `Hero.tsx` — title "Dein WM-Moment", subtitle "Dein Gesicht. Dein Land. Deine Legende."
- `CountryStep.tsx` — maps `COUNTRIES` to a responsive grid (`grid-cols-2 md:grid-cols-3 lg:grid-cols-4`), large flag + label buttons.
- `StyleStep.tsx` — reads `styles` from selected country, shows Retro / Modern cards (name + desc).
- `UploadStep.tsx` — file input + DSGVO note + link to `/datenschutz`.
- `Result.tsx` — generated image, Download, Share (Web Share API w/ clipboard fallback), "Noch eins" reset.
- `Footer.tsx` — "Made with ❤️ in Berlin → kiwasgeht.de 🐙".

Page state machine lives in `src/routes/index.tsx` (steps: country → style → upload → loading → result).

## Server routes (`src/routes/api/`)
1. `POST /api/describe-face` — accepts `{ imageBase64 }`, calls Gemini `google/gemini-3-flash-preview` via Lovable Gateway with multimodal `image_url` + face-description system prompt, returns `{ description }`.
2. `POST /api/generate-wm-image` — accepts `{ countryId, style, imageBase64, description }`, looks up prompt template from `COUNTRIES`, substitutes `[insert face description here]`, calls `openai/gpt-image-2` via Lovable Gateway `/v1/images/generations` with input image, returns `{ imageBase64 }`.
3. `POST /api/track` — minimal analytics endpoint, logs `{ event, props }` server-side.

All three apply the in-memory rate limiter (3 generations per IP per UTC day, keyed by `x-forwarded-for`). Rate limit only counts successful generations on route 2; describe-face and track are unmetered but share-IP guarded against abuse with a soft cap.

## Other files
- `src/lib/rate-limit.ts` — `Map<ip, { count, dayKey }>`, `consume(ip)` returns `{ ok, remaining }`.
- `src/lib/prompts.ts` — not needed; prompts live in `countries.ts`. (Skip.)
- `src/lib/analytics.ts` — `trackEvent(name, props)` POSTs to `/api/track`.
- `src/routes/datenschutz.tsx` — DSGVO page (short German privacy text).

## Secrets
Ensure `LOVABLE_API_KEY` exists via `ai_gateway--create`.

## Tech notes
- Lovable AI Gateway (gpt-image-2 + Gemini), no direct OpenAI key.
- In-memory rate limit (resets on deploy — acceptable for launch).
- No image persistence (DSGVO).
- Server routes (not `createServerFn`) so we can stream image bytes if needed and keep request bodies large (base64).

Proceeding to build.